#include "dynamic_string.h"
#include "scanner.h"
#include <stdio.h>
void func(dynamic_string_t *str)
{
    printf("%s funkcia \n",str->s);
}
int main()
{
token_t token;
token_t * tok = &token;
token_init(tok);
FILE *file = fopen("testinput2.txt","r");
get_source(file);
get_next_token(tok);
printf("%s\n",tok->attribute.string->s);
printf("%d\n",tok->type);
get_next_token(tok);
printf("%d\n",tok->type);
get_next_token(tok);
printf("%s\n",tok->attribute.string->s);
printf("%d\n",tok->type);
get_next_token(tok);
printf("%d\n",tok->type);
 return 0;
}