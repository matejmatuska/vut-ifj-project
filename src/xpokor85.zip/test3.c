#include "ST_stack.h"
#include "symtable.h"

void print_it(sym_tab_item_t *item)
{
    if (printf("%s\t%d\t%d\t%d\t%d\t%d\n", item->key,item->data.return_data_types->datatype,item->data.param_data_types->datatype,item->data.defined,item->data.declared,item->data.params) < 0)
        fprintf(stderr, "%s", "Cannot print on stdout\n");
}

int main()

{   
    ST_stack *scope = NULL;
    sym_tab_item_t *item_to_add;
    sym_tab_item_t *found;
    data_type list = create_data_type(INTEGER);
    add_data_type(list,STRING);
    //create our main scope
    push(&scope);
    item_to_add = sym_tab_add_item(scope->localtable,"xyz");
    sym_tab_add_data_function(item_to_add,list,list,true,false,32);
    item_to_add = sym_tab_add_item(scope->localtable,"y");
    sym_tab_add_data_var(item_to_add,list,true,false);
    item_to_add = sym_tab_add_item(scope->localtable,"z");
    sym_tab_add_data_function(item_to_add,list,list,true,false,3);
    printf("toto je global table\n");
    sym_tab_for_each(scope->localtable,&print_it);
    //prichadza zanorenie
    push(&scope);
    item_to_add = sym_tab_add_item(scope->localtable,"x");
     sym_tab_add_data_function(item_to_add,list,list,true,false,3245);
    item_to_add = sym_tab_add_item(scope->localtable,"z");
    sym_tab_add_data_function(item_to_add,list,list,true,false,3289);
    printf("toto je prva local table\n");
    sym_tab_for_each(scope->localtable,&print_it);
    found = scope_search(&scope,"z");
    //skusime dalsie zanorenie
    push(&scope);
    item_to_add = sym_tab_add_item(scope->localtable,"x");
    sym_tab_add_data_function(item_to_add,list,list,true,false,420);
    printf("toto je druha local table\n");
    sym_tab_for_each(scope->localtable,&print_it);
    pop(&scope);
    pop(&scope);
    //sme zase na globalnom...
     printf("toto je zase global table\n");
    sym_tab_for_each(scope->localtable,&print_it);
    printf("%d\n",isvar(scope->localtable,"y"));
    pop(&scope);
}