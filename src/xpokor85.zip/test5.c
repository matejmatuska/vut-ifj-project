#include "ST_stack.h"
#include "symtable.h"

void print_it(sym_tab_item_t *item)
{
    if (printf("%s\t%d\t%d\t%d\t%d\n", item->key,item->data.return_data_types->datatype,item->data.defined,item->data.declared,item->data.params) < 0)
        fprintf(stderr, "%s", "Cannot print on stdout\n");
}



int main()

{   
    ST_stack *scope = init_ST_stack();
    sym_tab_item_t *item_to_add;
    sym_tab_item_t *found;
    data_type list = NULL;
    list = add_data_type(list,INTEGER);
    list = add_data_type(list,STRING);
    data_type list1 = NULL;
    list1 = add_data_type(list1,INTEGER);
    list1 = add_data_type(list1,STRING);
    data_type list2 = NULL;
    list2 = add_data_type(list2,INTEGER);
    list2 =add_data_type(list2,STRING);
    data_type list3 = NULL;
    list3 = add_data_type(list3,INTEGER);
    list3 = add_data_type(list3,STRING);
    data_type list4 = NULL;
    list4 =add_data_type(list4,INTEGER);
    list4= add_data_type(list4,STRING);
    data_type list5 = NULL;
    list5 = add_data_type(list5,INTEGER);
    list5 = add_data_type(list5,STRING);
    //create our main scope
    push(&scope);
     item_to_add = sym_tab_add_item(top_table(scope),"xyz");
    sym_tab_add_data_var(item_to_add,list,true,false);
    item_to_add = sym_tab_add_item(top_table(scope),"abc");
    sym_tab_add_data_function(item_to_add,list1,list2,true,false,8012);
    item_to_add = sym_tab_add_item(top_table(scope),"xyz");
    sym_tab_add_data_var(item_to_add,list3,true,false);
   sym_tab_for_each(top_table(scope),&print_it);
    push(&scope);
    item_to_add = sym_tab_add_item(top_table(scope),"hej");
    sym_tab_add_data_function(item_to_add,list4,list5,true,false,32345);
    printf("%d\n",isvar(&scope,"abc"));
    if(found = scope_search(&scope,"ab"))
    printf("found\n");
    sym_tab_for_each(top_table(scope),&print_it);
    printf("error occured ups\n");
    free_ST_stack(&scope);
    printf("end");
}