#include "scanner.h"
#include "symtable.h"

void print_it(htab_data_t *data)
{
    if (printf("%s\t%d\t%d\t%d\t%d\t%d\t%d\n", data->key, data->count, data->token_type,data->item_type,data->datatype,data->defined,data->params) < 0)
        fprintf(stderr, "%s", "Cannot print on stdout\n");
}

int main()
{
    htab_t *global = htab_init(10);
    htab_lookup_add(global,"ahoj");
    htab_lookup_add(global,"ideto");
    htab_lookup_add(global,"noco");
    htab_lookup_add(global,"ahoj");
      htab_lookup_add(global,"ahoj");
    htab_for_each(global,&print_it);
    htab_t *local = htab_move(10,global);
    printf("now local table\n");
    htab_for_each(local,&print_it);
    printf("%ld\n",htab_size(global));
    printf("%ld\n",htab_size(local));
    printf("%ld\n",htab_bucket_count(global));
    printf("%ld\n",htab_bucket_count(local));
    htab_erase(local,"ahoj");
     htab_for_each(local,&print_it);
     htab_clear(local);
     htab_for_each(local,&print_it);
     htab_free(global);
}